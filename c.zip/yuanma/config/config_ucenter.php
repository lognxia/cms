<?php


define('UC_CONNECT', 'mysql');

define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'sql_127_0_0_70');
define('UC_DBPW', 'hxyfpkk3cjz66bDr');
define('UC_DBNAME', 'sql_127_0_0_70');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`sql_127_0_0_70`.pre_ucenter_');
define('UC_DBCONNECT', 0);

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'ybB5E7OdTfqfK4L8020en8h3k9NcX2Q8D0d6d16facJ8Y8bfi6w9T3N5D3M9q8wf');
define('UC_API', 'http://127.0.0.70/uc_server');
define('UC_APPID', '1');
define('UC_IP', '');
define('UC_PPP', 20);
?>