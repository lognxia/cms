<?php
//Discuz! cache file, DO NOT modify me!
//Identify: f5aeed062f5ec50375a543f2361ee2bc

$pluginsetting = array (
);
?>