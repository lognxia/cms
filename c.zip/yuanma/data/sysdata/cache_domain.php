<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 38262bf1e54d199eaee536eaed6dddef

$domain = array (
  'defaultindex' => 'forum.php',
  'holddomain' => 'www|*blog*|*space*|*bbs*',
  'list' => 
  array (
  ),
  'app' => 
  array (
    'portal' => '',
    'forum' => '',
    'group' => '',
    'home' => '',
    'default' => '',
  ),
  'root' => 
  array (
    'home' => '',
    'group' => '',
    'forum' => '',
    'topic' => '',
    'channel' => '',
  ),
);
?>