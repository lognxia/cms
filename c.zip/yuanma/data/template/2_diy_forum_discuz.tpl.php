<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('discuz');?><?php include template('common/header'); $pc = $_G['cache']['plugin']['pcasl_91']['slides'];

$pckeyword_arr = explode("\r\n",$pc);

foreach($pckeyword_arr as $pcarr){
$kv=explode("=",$pcarr);
$pcres[$kv[0]]=$kv[1];
}

$sj = $_G['cache']['plugin']['pcasl_91']['mobiles'];

$mokeyword_arr = explode("\r\n",$sj);

foreach($mokeyword_arr as $moarr){
$kv=explode("=",$moarr);
$mores[$kv[0]]=$kv[1];
}?><div style="padding:16px; background:#fff;">
    <div class="layui-carousel" id="pslide">
      <div carousel-item>
<?php if($pmobile == 2) { if(is_array($mores)) foreach($mores as $ide) { ?><div><img src="<?php echo $ide;?>" /></div>
<?php } } else { if(is_array($pcres)) foreach($pcres as $ide) { ?><div><img src="<?php echo $ide;?>" /></div>
<?php } } ?>
      </div>
    </div>
</div>
<div style="background:#fff; font-size:14px; font-weight:700; padding:0 0 16px 16px; margin-bottom:8px;">进MM群通道：Q群：88888888 群内福利多多</div>


<script src="template/pcasl_romantic/layui/layui.js" type="text/javascript"></script>

<script type="text/javascript">
layui.use('carousel', function(){
  var carousel = layui.carousel;
  carousel.render({
    elem: '#pslide'
    ,width: '100%'
,height:'280px'
    ,arrow: 'always'
    ,anim: 'fade'
  });
});
</script>

<div id="psheng" class="cl">
    <dl class="cl">
        <dt>东北华北：</dt>
        <dd class="cl">
        <a href="#">北京市</a>
        <a href="#">天津市</a>
        <a href="#">山东省</a>
        <a href="#">河北省</a>
        <a href="#">山西省</a>
        <a href="#">内蒙古</a>
        <a href="#">辽宁省</a>
        <a href="#">黑龙江省</a>
        <a href="#">吉林省</a>
        </dd>
    </dl>
    <dl class="cl" style="margin-top:10px;">
        <dt>华中华东：</dt>
        <dd class="cl">
        <a href="#">上海市</a>
        <a href="forum.php?mod=forumdisplay&amp;fid=2&amp;filter=sortid&amp;sortid=1&amp;searchsort=1&amp;shengfen=9">江苏省</a>
        <a href="#">浙江省</a>
        <a href="#">福建省</a>
        <a href="#">河南省</a>
        <a href="#">湖北省</a>
        <a href="#">安徽省</a>
        <a href="#">湖南省</a>
        <a href="#">江西省</a>
        </dd>
    </dl>
    <dl class="cl" style="margin-top:10px;">
        <dt style="height:auto;">华南：</dt>
        <dd class="cl">
        <a href="#">广东省</a>
        <a href="#">广西</a>
        <a href="#">海南省</a>
        </dd>
    </dl>
    <dl class="cl" style="margin-top:10px;">
        <dt>西北西南：</dt>
        <dd class="cl">
        <a href="#">重庆市</a>
        <a href="#">四川省</a>
        <a href="#">云南省</a>
        <a href="#">贵州省</a>
        <a href="#">陕西省</a>
        <a href="#">甘肃省</a>
        <a href="#">新疆</a>
        <a href="#">宁夏</a>
        <a href="#">青海省</a>
<a href="#">西藏</a>
        </dd>
    </dl>
</div><?php $pnew = DB::fetch_all("SELECT * FROM ".DB::table('forum_thread')." ORDER BY `dateline` DESC");?><div class="cl" style="margin-top:8px;"><?php if(is_array($pnew)) foreach($pnew as $list) { $cjimg = DB::result(DB::query("SELECT img FROM ".DB::table('pcasl_91')." WHERE tid=$list[tid]"));
$cjshenfen = DB::result(DB::query("SELECT shengfen FROM ".DB::table('pcasl_91')." WHERE tid=$list[tid]"));?><div class="index_list cl">
<a href="forum.php?mod=viewthread&amp;tid=<?php echo $list['tid'];?>" title="<?php echo $list['subject'];?>">
    <div class="list_l">
        <div class="ptitle"><?php echo $list['subject'];?></div>
        <div class="pdate"><span style="margin-right:8px;"><i class="iconfont icon-riqi5 pcaslicon"></i><?php echo date('Y-m-d',$list[dateline])?></span><span><i class="iconfont icon-chakan4 pcaslicon"></i><?php echo $list['views'];?></span></div>
        <div class="pmsg"><?php $pmsg = DB::result(DB::query("SELECT message FROM ".DB::table('forum_post')." WHERE tid=$list[tid]")); echo preg_replace ("/\[[a-z][^\]]*\]|\[\/[a-z]+\]/i",'',preg_replace("/\[attach\]\d+\[\/attach\]/i",'',$pmsg));?></div>
        <div class="pshengshi"><span><?php echo $cjshenfen;?></span></div>
    </div>
    <div class="list_r"><img src="<?php echo $cjimg;?>" alt="<?php echo $list['subject'];?>" /></div>
</a>
</div>
<?php } ?>

</div>

<?php if(empty($gid)) { ?><?php echo adshow("text/wp a_t");?><?php } ?>

<style id="diy_style" type="text/css"></style>

<?php if(empty($gid)) { ?>
<div class="wp">
<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
</div>
<?php } if(empty($_G['setting']['disfixednv_forumindex']) ) { ?><script>fixed_top_nv();</script><?php } include template('common/footer'); ?>