<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$arr = $_G['cache']['plugin']['pcasl_91'];

$jfs = $arr['jf'];

$gmjf = $arr['price'];

$ligin_jf = DB::result(DB::query("SELECT extcredits{$gmjf} FROM ".DB::table('common_member_count')." WHERE uid=$_G[uid]")); //登录用户积分

if($_G['uid']){
	if($ligin_jf>=$jfs){
        $setarr = array(
                'tid' => $_GET['tid'],
                'uid' => $_G['uid'],
        );
        DB::insert('pcasl_91_gm',$setarr,1);
		DB::query("UPDATE ".DB::table('common_member_count')." SET extcredits{$gmjf}=extcredits{$gmjf}-{$jfs} WHERE uid=$_G[uid]");
		showmessage('购买成功!','forum.php?mod=viewthread&tid='.$_GET[tid],null,array('alert' => 'right'));
	}else{
		showmessage($arr['vip']);
	}
}else{
	showmessage('系统检测到您未登录,请先登录!','member.php?mod=logging&action=login');
}