<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

define("layui_root", "source/plugin/pcasl_91/layui");

class plugin_pcasl_91 {
	function global_usernav_extra1(){
		global $_G;
		if($_G['basescript'] == 'search'){
			return '<meta name="viewport" content="width=device-width, initial-scale=1.0"/><link rel="stylesheet" href="template/pcasl_romantic/layui/css/self.css" />';
		}
	}
}

class plugin_pcasl_91_search extends plugin_pcasl_91{
	function forum_top(){
		return '<meta name="viewport" content="width=device-width, initial-scale=1.0"/><link rel="stylesheet" href="template/pcasl_romantic/layui/css/self.css" />';
	}
}
class plugin_pcasl_91_forum extends plugin_pcasl_91 {
	
	function post_top(){
		
		global $_G;
		
		$str = $_G['cache']['plugin']['pcasl_91']['pro'];
		
		$keyword_arr = explode("\r\n", $str);
		$res=array();
		foreach($keyword_arr as $arr){
			$kv=explode("=",$arr);
			$res[$kv[0]]=$kv[1];
		}
		
		include template('pcasl_91:post');
		
		return $html;
		
	}
	
	function post_showimg_dzx_message($post) {
		global $_G;
		$tids = $_GET['tid'];
		if($post['param']['0'] == 'post_newthread_succeed'){ //发表新帖
			$setarr = array(
				'tid' => $post['param'][2]['tid'],
				'img' => $_GET['pcasl_img'],
				'shengfen' => $_GET['pcasl_address'],
				'age' => $_GET['age'],
				'level' => $_GET['level'],
				'consumption' => $_GET['consumption'],
				'items' => implode(',',$_GET['items']),
				'qq' => $_GET['qq'],
				'wx' =>$_GET['wx'],
				'telephone' => $_GET['telephone'],
				'address' => $_GET['address'],
			);
			DB::insert('pcasl_91',$setarr,1);
		}elseif($post['param']['0'] == 'post_edit_succeed'){ //编辑帖子
			$setarr = array(
				'tid' => $post['param'][2]['tid'],
				'img' => $_GET['pcasl_img'],
				'shengfen' => $_GET['pcasl_address'],
				'age' => $_GET['age'],
				'level' => $_GET['level'],
				'consumption' => $_GET['consumption'],
				'items' => implode(',',$_GET['items']),
				'qq' => $_GET['qq'],
				'wx' =>$_GET['wx'],
				'telephone' => $_GET['telephone'],
				'address' => $_GET['address'],
			);
			DB::update('pcasl_91',$setarr,'tid='.$tids);
		}
	}
	
}