<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$parent_id = $_GET['parent_id'];

$type = $_GET['type'];

$sheng = DB::fetch_all("SELECT * FROM ".DB::table('global_region')." WHERE parent_id=$parent_id");//市

$sql = DB::fetch_all("SELECT * FROM ".DB::table('global_region')." WHERE parent_id=1 and region_type=2");//市

if($type == "" || $parent_id ==""){
	
	exit(json_encode(array("flag" => false, "msg" => "查询类型错误!")));
	
}else{
	
	$arr = DB::fetch_all("SELECT * FROM ".DB::table('global_region')." WHERE parent_id=$parent_id and region_type=$type");
	
}

$provinces_json = json_encode($arr);

exit($provinces_json);