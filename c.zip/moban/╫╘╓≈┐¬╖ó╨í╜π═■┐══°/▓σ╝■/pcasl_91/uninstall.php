<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$db_a = DB::table("pcasl_91");
$db_b = DB::table("pcasl_91_gm");
$db_c = DB::table("global_region");
$sql = <<<EOF
DROP TABLE IF EXISTS `$db_a`;
DROP TABLE IF EXISTS `$db_b`;
DROP TABLE IF EXISTS `$db_c`;
EOF;

runquery($sql);
$finish = true;

?>