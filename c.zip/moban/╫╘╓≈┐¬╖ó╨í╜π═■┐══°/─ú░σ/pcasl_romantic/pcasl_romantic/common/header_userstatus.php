<?php echo '你不能看此模板的内容';exit;?>
<!--{if $_G['uid']}-->
<div id="header_user">
    <div class="user_list">
        <a href="home.php?mod=space&uid=$_G[uid]" class="user_touxiang"><!--{avatar($_G[uid],small)}--><span>{$_G[member][username]}</span></a>
        <ul>
			<!--{hook/global_usernav_extra1}-->
			<!--{hook/global_usernav_extra4}-->
			<!--{hook/global_usernav_extra2}-->
			<!--{hook/global_usernav_extra3}-->
            <li><a href="home.php?mod=spacecp">设置</a></li>
            <li><a href="home.php?mod=space&do=pm">消息</a></li>
            <li><a href="home.php?mod=space&do=notice">提醒</a></li>
            {if $_G[fid]}
            <li><a href="forum.php?mod=post&action=newthread&fid={$_G[fid]}">发帖</a></li>
            {/if}
            <!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
            <li><a href="admin.php" target="_blank">管理中心</a></li>
            <!--{/if}-->
        </ul>
    </div>
    <div id="user_tuichu"><a href="member.php?mod=logging&action=logout&formhash={eval echo formhash();}">退出</a></div>
</div>
<!--{elseif !empty($_G['cookie']['loginuser'])}-->
<p>
	<strong><a id="loginuser" class="noborder"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></strong>
	<span class="pipe">|</span><a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)">{lang activation}</a>
	<span class="pipe">|</span><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
</p>
<!--{elseif !$_G[connectguest]}-->
<div id="header_login">
	<ul>
    	<li><a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href);hideWindow('register');">登录</a></li>
		<li><a href="member.php?mod=register">注册</a></li>
	</ul>
</div>
<!--{else}-->
<div id="um">
	<div class="avt y"><!--{avatar(0,small)}--></div>
	<p>
		<strong class="vwmy qq">{$_G[member][username]}</strong>
		<!--{hook/global_usernav_extra1}-->
		<span class="pipe">|</span><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
	</p>
	<p>
		<a href="home.php?mod=spacecp&ac=credit&showcredit=1">{lang credits}: 0</a>
		<span class="pipe">|</span>{lang usergroup}: $_G[group][grouptitle]
	</p>
</div>
<!--{/if}-->